"""
Functional tests for PyForbes.
"""