"""
Unit Testing for pyforbes.vectorizer.doc2vec()
"""

import gensim
import numpy as np
import pyforbes
import unittest

from tests.data import article_data


class doc2vecTestCase(unittest.TestCase):
    """
    Test Cases for pyforbes.vectorizer.doc2vec()
    """
    
    def setUp(self):
        
        # Training Mode
        self.vec_train = pyforbes.vectorizer.doc2vec.doc2vec(corpus='tests/data/doc2vec.train.cor')
        
        # Production Mode
        self.vec_prod = pyforbes.vectorizer.doc2vec.doc2vec(model='tests/models/50d.test.doc2vec')
    
    def test_init_exception(self):
        """
        pyforbes.vectorizer.doc2vec() raises Exception
        """
        with self.assertRaises(Exception):
            pyforbes.vectorizer.doc2vec.doc2vec(corpus=None, model=None)
    
    def test_init_vec_train(self):
        """
        pyforbes.vectorizer.doc2vec().corpus returns a list
        """
        self.assertIsInstance(self.vec_train.corpus, list)
    
    def test_init_vec_prod(self):
        """
        pyforbes.vectorizer.doc2vec().model returns a Gensim model
        """
        self.assertIsInstance(self.vec_prod.model, gensim.models.doc2vec.Doc2Vec)
    
    def test_vectorize(self):
        """
        pyforbes.vectorizer.doc2vec().vectorize() returns a numpy array
        """
        vector = self.vec_prod.vectorize(article_data)
        
        self.assertIsInstance(vector, np.ndarray)
    
    def test_train(self):
        """
        pyforbes.vectorizer.doc2vec().train() trains and saves a Gensim model
        pyforbes.vectorizer.doc2vec().evaluate() runs without exceptions
        """
        _ = self.vec_train.train(size=50, epochs=55, **{'min_count':2})
        
        self.assertIsInstance(self.vec_train.model, gensim.models.doc2vec.Doc2Vec)
        
        self.vec_train.evaluate('tests/data/doc2vec.test.cor', verbose=False)
        
