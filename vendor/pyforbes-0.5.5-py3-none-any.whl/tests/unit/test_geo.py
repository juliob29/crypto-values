"""
Unit tests for the Geo API.
"""
import pyforbes
import unittest

from datetime import datetime, timedelta


class GeoTestCase(unittest.TestCase):
    """
    Test case for the Geo API interface.
    """

    def setUp(self):

        self.geo = pyforbes.Geo()

    def test_return_results(self):
        """
        Geo().articles() returns list of articles.
        """
        results = self.geo.articles(region='USUS', day=14, hour=15)
        self.assertIsInstance(results, list)
