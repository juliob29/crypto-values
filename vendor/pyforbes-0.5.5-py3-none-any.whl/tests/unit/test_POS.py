"""
Unit Testing for pyforbes.analysis.POS.Tagger()
"""
import spacy
import unittest
import pyforbes

from tests.data import article_data


class TaggerTestCase(unittest.TestCase):
    """
    Test Cases for pyforbes.analysis.pos.Tagger()
    """
    def setUp(self):
        self.tagger = pyforbes.analysis.pos.Tagger()
    
    def test_init(self):
        """
        pyforbes.analysis.pos.Tagger().labels returns a dict
        pyforbes.analysis.pos.Tagger().template returns a str
        """
        self.assertIsInstance(self.tagger.labels, dict)
        self.assertIsInstance(self.tagger.template, str)
    
    def test_annotate(self):
        """
        pyforbes.analysis.pos.Tagger().annotate() returns a list of tuples of str
        """
        results = self.tagger.annotate(article_data, display=None)
        
        self.assertIsInstance(results, list)
        self.assertIsInstance(results[0], tuple)
        self.assertIsInstance(results[0][0], str)
    