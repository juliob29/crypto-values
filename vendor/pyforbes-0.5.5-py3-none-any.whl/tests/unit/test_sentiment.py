"""
Unit tests for the Sentiment class.
"""
import pyforbes
import unittest

from tests.data import article_data


class SentimentTestCase(unittest.TestCase):
    """
    Test case for pyforbes.models.Sentiment()
    """

    def setUp(self):
        self.sentiment = pyforbes.models.Sentiment()
    
    def test_status_returns_dict(self):
        """
        pyforbes.models.Sentiment().status() returns a dictionary.
        """
        results = self.sentiment.status()

        self.assertIsInstance(results, dict)

    def test_returns_sentiment_estimate(self):
        """
        pyforbes.models.Sentiment().text() returns a sentiment estimate.
        """
        results = self.sentiment.text(text=article_data)

        self.assertIsInstance(results['sentiment'], float)
    
    def test_evalutes_sentiment_from_article(self):
        """
        pyforbes.models.Summarizer().article() returns sentiment estimate.
        """
        results = self.sentiment.article(article='blogAndPostId/blog/post/4398-736')

        self.assertIsInstance(results['sentiment'], float)
    