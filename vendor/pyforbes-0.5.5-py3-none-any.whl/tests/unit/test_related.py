"""
Unit tests for the Related class.
"""
import pyforbes
import unittest

from datetime import datetime


class RelatedTestCase(unittest.TestCase):
    """
    Test case for the Related() class.
    """

    def setUp(self):
        self.related = pyforbes.Related()

    def test_return_related_articles(self):
        """
        Related().article() return list of related articles.
        """
        results = self.related.article('blogAndPostId/blog/post/1435-2492')
        self.assertGreater(len(results), 0)

    def test_return_combined_articles(self):
        """
        Related().combined() returns combined list of related articles.
        """
        articles = ['blogAndPostId/blog/post/1435-2492', 'blogAndPostId/blog/post/1435-2466']
        results = self.related.combined(ids=articles, operation='sum')
        
        self.assertGreater(len(results), 0)
        
        with self.assertRaises(ValueError):
            self.related.combined(ids='foo')
