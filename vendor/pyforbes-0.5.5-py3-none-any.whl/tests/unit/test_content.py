"""
Unit tests for the Content class.
"""
import pyforbes
import unittest

from datetime import datetime, timedelta


class ContentTestCase(unittest.TestCase):
    """
    Test case for the Content() class.
    """

    def setUp(self):
        self.content = pyforbes.Content()
        self.start = datetime(2017, 1, 1)
        self.stop = datetime(2017, 2, 1)

    def test_returns_recent_articles(self):
        """
        Content().recent_articles() returns recent articles.
        """
        results = self.content.recent_articles()

        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 10)

    def test_article_raises_error_when_wrong_day_inputs(self):
        """
        Content().article_list() raises error when wrong date input is passed.
        """
        with self.assertRaises(ValueError):
            self.content.article_list(
                start='2017-01-01', stop='2017-02-01', fields=['title'], n=10)

    def test_epoch_time_retrieval_works(self):
        """
        Content().article_list() can use UNIX Epoch time interval specifications.
        """
        start = int(datetime.strptime('2017-01-01', '%Y-%m-%d').strftime('%s'))
        stop = int(datetime.strptime('2017-02-01', '%Y-%m-%d').strftime('%s'))
        results = self.content.article_list(
            start=start, stop=stop, fields=['title', 'date', 'naturalId'], n=10, epoch=True)

        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 10)

        outside_time_period = [
            a for a in results
            if datetime.fromtimestamp(a['date'] / 1000).strftime('%Y-%m-%d') >
            '2017-02-02'
        ]
        self.assertEqual(len(outside_time_period), 0)

    def test_returns_articles_within_period(self):
        """
        Content().article_list() returns articles within a time period.
        """
        results = self.content.article_list(
            start=self.start, stop=self.stop, fields=['title', 'date', 'naturalId'], n=10)

        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 10)

        outside_time_period = [
            a for a in results
            if datetime.fromtimestamp(a['date'] / 1000).strftime('%Y-%m-%d') >
            '2017-02-02'
        ]
        self.assertEqual(len(outside_time_period), 0)

        #
        #  Running the same test, but without
        #  a limit clause.
        #
        results = self.content.article_list(
            start=self.start, stop=self.stop, fields=['title', 'date'])

        self.assertIsInstance(results, list)

    def test_article_retrieves_metadata(self):
        """
        Content().article() retrieves the metadata for a single article.
        """
        parameters = [{
            'method': 'natural_id',
            'identifier': 'blogAndPostId/blog/post/2989-26811'
        }, {
            'method': 'url',
            'identifier': 'https://www.forbes.com/sites/lizryan/2017/03/21/ten-things-never-ever-to-do-before-youre-hired/'
        }]
        for param in parameters:
            results = self.content.article(**param)
            self.assertEqual(
                results['title'],
                "Ten Things Never, Ever To Do Before You're Hired")

    def test_article_raises_error_if_does_not_exist(self):
        """
        Content().article() raises ValueError if ID doesn't exist.
        """
        parameters = {
            'method': 'url',
            'identifier': 'https://www.forbes.com/sites/lizryan/2017/03/21/la-li-lu-le-lo'
        }

        with self.assertRaises(ValueError):
            self.content.article(**parameters)

    def test_encoding_problems(self):
        """
        Content().article() returns correctly encoded object
        """
        parameters = {
            'method': 'url',
            'identifier': 'https://www.forbes.com/sites/learnvest/2014/04/04/resume-mistakes-you-cant-afford-to-make/'
        }
        result = self.content.article(**parameters)
        self.assertIn('é',result.get('title'))

    def test_raises_error_with_wrong_format(self):
        """
        Content().article() raises error when wrong format is used.
        """
        options = [{
            'method': 'url',
            'identifier': 'www.forbes.com/sites/learnvest/2014/04/04/resume-mistakes-you-cant-afford-to-make/'
        },
        {
            'method': 'natural_id',
            'identifier': 'foo'
        }]
        for o in options:
            with self.assertRaises(ValueError):
                self.content.article(**o)

    def test_only_returns_ids_if_specified(self):
        """
        Content().recent_articles(only_ids=True) returns a list of natural IDs.
        """
        results = self.content.recent_articles(only_ids=True)

        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 10)
        self.assertTrue(all([isinstance(i, str) for i in results]))

    def test_urls_are_parsed_correctly(self):
        """
        Content().article(method='url') parses URLs correctly.
        """
        #  Replaces https with http.
        url = 'https://www.forbes.com/sites/kellyphillipserb/2018/04/25/irs-warns-on-yet-another-new-twist-on-tax-phone-scams/'
        results = self.content.article(identifier=url, method='url')
        self.assertIsInstance(results, dict)

        # Adds www if not present.
        url = 'http://forbes.com/sites/kellyphillipserb/2018/04/25/irs-warns-on-yet-another-new-twist-on-tax-phone-scams/'
        results = self.content.article(identifier=url, method='url')
        self.assertIsInstance(results, dict)
        
        # Adds final / if not present.
        url = 'https://www.forbes.com/sites/kellyphillipserb/2018/04/25/irs-warns-on-yet-another-new-twist-on-tax-phone-scams'
        results = self.content.article(identifier=url, method='url')
        self.assertIsInstance(results, dict)
    
    def test_filtering_of_properties_work(self):
        """
        Content().article_list() filters correctly based on fields.
        """
        start = (datetime.now() - timedelta(days=3))
        stop = datetime.now()
        with self.assertRaises(ValueError):
            self.content.article_list(start=start, stop=stop, n=3, fields=[])

        expected_fields = ['title', 'uri']
        result = self.content.article_list(start=start, stop=stop, n=3, fields=expected_fields)
        for article in result:
            self.assertTrue(all([x in article.keys() for x in expected_fields]))
    
    def test_author_list_returns_list_of_authors(self):
        """
        Content().author_list() returns a list of authors.
        """
        results = self.content.author_list()
        for author in results:
            self.assertTrue(type(author['name']), str)

    def test_content_raises_error_if_article_doesnt_exist(self):
        """
        Content().article() raises error if article doesn't exist.
        """
        article = 'foo/bar'
        with self.assertRaises(ValueError):
            self.content.article(identifier=article)

    def test_author_articles_returns_list_of_articles(self):
        """
        Content().author_articles() returns a list of articles.
        """
        author_id = 'blogAuthorId/blog/author/609'
        results = self.content.author_articles(author_id)
        self.assertGreater(len(results), 0)
    
    def test_author_articles_raises_error_if_author_doesnt_exist(self):
        """
        Content().author_articles() raises error if author doesn't exist.
        """
        with self.assertRaises(ValueError):
            self.content.author_articles('foo')

    def test_content_article_raises_error_if_article_doesnt_exist(self):
        """
        Content().article() raises error if object isn't an article.
        """
        bad_articles = [
            'galleryId/57fe651aa7ea4357a3e00dbb',
            'video/brightcove/5775455126001'
        ]
        for article in bad_articles:
            with self.assertRaises(ValueError):
                self.content.article(identifier=article)

    def test_fills_article_property(self):
        """
        Content().article_list() fills article properties if they don't exist.
        """
        spurious_property = 'editorsPick'
        results = self.content.article_list(
            start=datetime(2018, 5, 29, 21, 40), 
            stop=datetime(2018, 5, 29, 21, 48), 
            fields=['title', 'date', 'naturalId', spurious_property], n=10)
        
        for article in results:
            self.assertIn(spurious_property, article.keys())

    def test_channels_returns_list_of_channels(self):
        """
        Content().channels() returns a list of channels.
        """
        results = self.content.channels()

        self.assertIsInstance(results, list)
        for channel in results:
            self.assertIn('id', channel.keys())
            self.assertIn('name', channel.keys())

    def test_channels_counts_sections_if_they_dont_exist(self):
        """
        Content().channels() counts sections if user doesn't request them.
        """
        results = self.content.channels(sections=False)

        self.assertIsInstance(results, list)
        for channel in results:
            self.assertIsInstance(channel['sections'], int)
    
    def test_hashtags_returns_a_list_of_hashtags(self):
        """
        Content().hashtags() returns a list of hashtags.
        """
        results = self.content.hashtags()
        
        self.assertIsInstance(results, list)
        self.assertGreater(len(results), 10)

    def test_articles_by_hashtag_returns_list_of_articles(self):
        """
        Content().articles_by_hashtag() returns articles for a given hashtag.
        """
        hashtag = 'InTheRing'
        results = self.content.articles_by_hashtag(hashtag=hashtag)
    
        self.assertTrue(all([hashtag in x['hashtags'] for x in results]))

    def test_articles_by_hashtag_raises_error_if_hashtag_doesnt_exist(self):
        """
        Content().articles_by_hashtag() raises error if hashtag doesn't exist.
        """
        hashtag = 'FooBar'

        with self.assertRaises(ValueError):
            self.content.articles_by_hashtag(hashtag=hashtag)
