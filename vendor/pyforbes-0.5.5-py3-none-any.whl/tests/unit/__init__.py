"""
Unit tests for the Forbes package.
"""