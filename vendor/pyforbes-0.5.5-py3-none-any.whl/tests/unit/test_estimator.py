"""
Unit tests for the Estimator class.
"""
import pyforbes
import unittest

from tests.data import article_data


class EstimatorTestCase(unittest.TestCase):
    """
    Test case for pyforbes.models.Estimator()
    """

    def setUp(self):
        self.estimator = pyforbes.models.Estimator()
    
    def test_status_returns_dict(self):
        """
        pyforbes.models.Estimator().status() returns a dictionary.
        """
        results = self.estimator.status()

        self.assertIsInstance(results, dict)

    def test_returns_prediction(self):
        """
        pyforbes.models.Estimator().text() returns a prediction.
        """
        results = self.estimator.text(text=article_data)

        self.assertIsInstance(results, dict)
        self.assertIsInstance(results['composite_score'], float)
