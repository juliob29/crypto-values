"""
Unit tests for the Search class.
"""
import pyforbes
import unittest


class SearchTestCase(unittest.TestCase):
    """
    Test case for the Content() class.
    """

    def setUp(self):
        self.search = pyforbes.Search()
        self.text_search = 'Donald Trump'

    def test_returns_search_results(self):
        """
        Search().text() returns a list of results.
        """
        results = self.search.text(text=self.text_search)

        self.assertIsInstance(results, dict)
        self.assertGreater(len(results['results']), 0)

    def test_returns_no_results(self):
        """
        Search().text() does not return results for known bad query.
        """
        results = self.search.text(text='1d8d08cc2254')

        self.assertIsInstance(results, dict)
        self.assertEqual(len(results['results']), 0)
