"""
Unit tests for the HeadlineOptimizer class.
"""
import pyforbes
import unittest

from tests.data import article_data


class HeadlineOptimizerTestCase(unittest.TestCase):
    """
    Test case for pyforbes.models.HeadlineOptimizer()
    """

    def setUp(self):
        self.optimizer = pyforbes.models.HeadlineOptimizer()
    
    def test_status_returns_dict(self):
        """
        pyforbes.models.HeadlineOptimizer().status() returns a dictionary.
        """
        results = self.optimizer.status()

        self.assertIsInstance(results, dict)

    #
    #  NOTE: the headline optimizer was deployed with
    #  a non-warden comformant issue. That needs to
    #  be fixed prior to having this test work
    #  as expected.
    #
    # def test_returns_suggestions(self):
    #     """
    #     pyforbes.models.HeadlineOptimizer().title() returns suggestions.
    #     """
    #     results = self.optimizer.title(title=article_data)

    #     self.assertIsInstance(results, dict)
    #     self.assertIsInstance(results['title_strength'], list)
    #     self.assertIsInstance(results['title_weakness'], list)
