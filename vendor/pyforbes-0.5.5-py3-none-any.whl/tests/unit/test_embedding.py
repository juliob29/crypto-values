"""
Unit tests for the Embedding utilities class.
"""

import keras
import pyforbes
import unittest

import numpy as np

from tests.data import article_data


class EmbeddingTestCase(unittest.TestCase):
    """
    Test cases for pyforbes.vectorizer.Embedding()
    """
    
    def setUp(self):
        self.GloVe_train = pyforbes.vectorizer.Embedding('tests/data/50d.test.GloVe', mode='train')
        self.GloVe_prod = pyforbes.vectorizer.Embedding('tests/models/50d.test.word2idx')
    
    def test_init_mode_train(self):
        """
        pyforbes.vectorizer.Embedding().word2idx returns a dictionary
        pyforbes.vectorizer.Embedding().idx2word returns a dictionary
        pyforbes.vectorizer.Embedding().word2vec returns a dictionary
        """
        self.assertIsInstance(self.GloVe_train.word2idx, dict)
        self.assertIsInstance(self.GloVe_train.idx2word, dict)
        self.assertIsInstance(self.GloVe_train.word2vec, dict)
        
    def test_init_mode_production(self):
        """
        pyforbes.vectorizer.Embedding().word2idx returns a dictionary
        pyforbes.vectorizer.Embedding().idx2word returns `None`
        pyforbes.vectorizer.Embedding().word2vec returns `None`
        """
        self.assertIsInstance(self.GloVe_prod.word2idx, dict)
        self.assertIsNone(self.GloVe_prod.idx2word)
        self.assertIsNone(self.GloVe_prod.word2vec)
    
    def test_sent2idx_returns_array(self):
        """
        pyforbes.vectorizer.Embedding().sent2idx() returns a list
        """
        X = np.array(article_data.strip().split('\n'))
        X_idx = self.GloVe_train.sent2idx(X, word2idx=None, max_len=30)
        
        self.assertIsInstance(X_idx, np.ndarray)
        
    def test_custom_embedding_returns_keras_layer(self):
        """
        pyforbes.vectorizer.Embedding().custom_embedding() returns a Keras layer
        """
        custom_layer = self.GloVe_train.custom_embedding(word2vec=None, word2idx=None, trainable=False)
        
        self.assertIsInstance(custom_layer, keras.layers.embeddings.Embedding)

