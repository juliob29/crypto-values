"""
Unit tests for the ReadingComplexity class.
"""
import pyforbes
import unittest

from tests.data import article_data


class ReadingComplexityTestCase(unittest.TestCase):
    """
    Test case for pyforbes.models.ReadingComplexity()
    """

    def setUp(self):
        self.reading_complexity = pyforbes.models.ReadingComplexity()
    
    def test_status_returns_dict(self):
        """
        pyforbes.models.ReadingComplexity().status() returns a dictionary.
        """
        results = self.reading_complexity.status()

        self.assertIsInstance(results, dict)

    def test_returns_list_with_setences(self):
        """
        pyforbes.models.ReadingComplexity().text() returns a summary of text.
        """
        results = self.reading_complexity.text(text=article_data)

        self.assertIsInstance(results['statistics'], dict)
        self.assertIsInstance(results['estimate'], float)
    
    def test_queries_summarizer_based_on_article_id(self):
        """
        pyforbes.models.ReadingComplexity().article() returns a summary of text.
        """
        results = self.reading_complexity.article(article='blogAndPostId/blog/post/4398-736')

        self.assertIsInstance(results['statistics'], dict)
        self.assertIsInstance(results['estimate'], float)
