"""
Unit tests for the Summarizer class.
"""
import pyforbes
import unittest

from tests.data import article_data


class SummarizerTestCase(unittest.TestCase):
    """
    Test case for pyforbes.models.Summarizer()
    """

    def setUp(self):
        self.summarizer = pyforbes.models.Summarizer()
    
    def test_status_returns_dict(self):
        """
        pyforbes.models.Summarizer().status() returns a dictionary.
        """
        results = self.summarizer.status()

        self.assertIsInstance(results, dict)

    def test_returns_list_with_setences(self):
        """
        pyforbes.models.Summarizer().text() returns a summary of text.
        """
        results = self.summarizer.text(text=article_data)

        self.assertIsInstance(results['summary'], list)
        self.assertIsInstance(results['keywords'], list)
        self.assertGreater(len(results['summary']), 0)
        self.assertGreater(len(results['keywords']), 0)
    
    def test_queries_summarizer_based_on_article_id(self):
        """
        pyforbes.models.Summarizer().article() returns a summary of text.
        """
        results = self.summarizer.article(article='blogAndPostId/blog/post/4398-736')

        self.assertIsInstance(results['summary'], list)
        self.assertIsInstance(results['keywords'], list)
        self.assertGreater(len(results['summary']), 0)
        self.assertGreater(len(results['keywords']), 0)
    
    def test_value_error_raise_if_text_is_too_short(self):
        """
        pyforbes.models.Summarizer().text() raises ValueError if too short.
        """
        with self.assertRaises(ValueError):
            self.summarizer.text(text='foo')
