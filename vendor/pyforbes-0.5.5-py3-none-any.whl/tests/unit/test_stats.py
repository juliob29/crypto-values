"""
Unit tests for the Stats class.
"""
import pyforbes
import unittest

from datetime import datetime


class StatsTestCase(unittest.TestCase):
    """
    Test case for the Stats() class.
    """
    def setUp(self):
        self.stats = pyforbes.Stats()
        self.recent_article = pyforbes.Content().recent_articles(n=1)[0]['naturalId']

    def test_returns_top_articles(self):
        """
        Stats().top() return the top N articles.
        """
        results = self.stats.top(n=10)

        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 10)

    def test_statistics_work_for_an_article(self):
        """
        Stats().article() returns statistics for a given article.
        """
        result = self.stats.article(identifier='blogAndPostId/blog/post/2989-26811',
                                    method='natural_id')

        self.assertIsInstance(result, list)

    def test_statistics_work_for_different_precisions(self):
        """
        Stats().article() work for different periods.
        """
        periods = ['day', 'month', 'year']
        for p in periods:
            result = self.stats.article(identifier=self.recent_article,
                                        method='natural_id', precision=p)

            self.assertIsInstance(result, list)

    def test_method_url_raises_error(self):
        """
        Stats().article(method='url') raises error.
        """
        with self.assertRaises(NotImplementedError):
            self.stats.article(identifier='foo', method='url')

    def test_top_returns_parsed_results(self):
        """
        Stats().top() returns a list of parsed articles.
        """
        expected_keys = ['published_at', 'natural_id', 'title', 'url']
        result = self.stats.top(n=10, parse=True)
        for article in result:
            self.assertTrue(any([x in article.keys() for x in expected_keys]))
