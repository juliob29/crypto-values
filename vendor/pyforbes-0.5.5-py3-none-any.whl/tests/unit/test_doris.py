# """
# Unit tests for the Doris API.
# """
# import pyforbes
# import unittest

# from datetime import datetime, timedelta


# class DorisTestCase(unittest.TestCase):
#     """
#     Test case for the Doris API interface.
#     """

#     def setUp(self):
#         self.doris = pyforbes.Doris()

#     def test_returns_results(self):
#         """
#         Doris().graph() returns results.
#         """
#         stop = datetime.now()
#         start = stop - timedelta(days=1)
#         results = self.doris.graph(article='blogAndPostId/blog/post/2989-25452', 
#                                    start=start, stop=stop)

#         self.assertIsInstance(results, dict)
#         self.assertIsInstance(results['results'], list)
#         self.assertTrue(results['success'])
