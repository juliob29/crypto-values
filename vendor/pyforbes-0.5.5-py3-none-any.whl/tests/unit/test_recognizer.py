"""
Unit tests for the EntitiesRecognizer class.
"""
import pyforbes
import unittest

from tests.data import article_data


class EntitiesRecognizerTestCase(unittest.TestCase):
    """
    Test case for pyforbes.models.EntitiesRecognizer()
    """

    def setUp(self):
        self.recognizer = pyforbes.models.EntitiesRecognizer()
    
    def test_status_returns_dict(self):
        """
        pyforbes.models.EntitiesRecognizer().status() returns a dictionary.
        """
        results = self.recognizer.status()

        self.assertIsInstance(results, dict)

    def test_returns_list_of_entities(self):
        """
        pyforbes.models.EntitiesRecognizer().text() returns a list of entities.
        """
        results = self.recognizer.text(text=article_data)

        self.assertIsInstance(results, list)
