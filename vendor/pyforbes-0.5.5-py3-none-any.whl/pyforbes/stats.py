"""
Logic for handling methods from the StatsAPI.
"""
import requests

from pyforbes.content import Content
from datetime import datetime, timedelta


class Stats:
    """
    Class that representing the interface with 
    Forbes' StatsAPI.
    """
    def __init__(self):
        self.url = 'http://statsapi.forbes.com:8080/statsapi'
        self.content = Content()

        #
        #  TODO: Check the limits with Mads.
        #
        self.precision_day_limits = {
            'day': 30,
            'month': 365,
            'year': float('inf')
        }

    def __date_format(self, precision):
        """
        Returns a strptime representation of a given
        precision that is formatted according to the 
        specifications of the StatsAPI.

        Parameters
        ----------
        precision: str
            One of the available precisions. If
            precision isn't available, a KeyError
            will be raised.
        
        Returns
        -------
        A string with the strptime representation
        of a given precision.
        """
        date_format = {
            'year': '%Y',
            'month': '%Y%m',
            'day': '%Y%m%d'
        }
        return date_format[precision]
    
    def __publication_date(self, article):
        """
        Protected method that retrieves the publication date
        for a given article in a datetime() format. This
        works as an utility method for other methods to
        check when an article was published.

        Parameters
        ----------
        article: str
            Natural ID or URL of article to look for.
        
        Returns
        -------
        datetime()
            A datetime() object representing the
            date and time that an article was published.
        """
        methor = 'natural_id'
        if 'http' in article:
            method = 'url'

        return datetime.fromtimestamp(self.content.article(article)['timestamp'] / 1000)
    
    def top(self, n=10, statistic=['PV'], parse=True):
        """
        Method for retrieving a list of the top content elements.
        This includes stories, galleries, videos, etc.

        Parameters
        ----------
        n: int, default 10
            Number of top articles to retrieve.

        statistic: list, default ['PV']
            Statistics type to use in ordering. Available statistics are:
                
                * 'PV': pageviews
                * 'FB': Facebook share-clicks
                * 'UV': unique visitors
                * 'TW': Twitter share-clicks
                * 'MB': mobile pageviews
        
        parse: bool, default True
            If the contents should be parsed into an
            easily manageable format as follows:

            {
                 'natural_id': 'foo',
                 'published_at': datetime(),
                 'title': 'Title',
                 'url': 'http://...'
            }

        Returns
        -------
        r: dict
            List of dictionaries with the list of top 
            articles.

        """
        payload = '/topN?n={}&rank={}'.format(n, ','.join(statistic))
        url = self.url + payload

        result = requests.get(url)
        r = result.json()['contentList']

        parsed_results = []
        if parse:
            for article in r:
                content_data = self.content.article(article['uri'], method='url')
                parsed_results.append({
                    'natural_id': content_data['naturalId'],
                    'published_at': datetime.fromtimestamp(content_data['timestamp'] / 1000),
                    'title': content_data['title'],
                    'url': content_data['uri']
                })
        
            r = parsed_results

        return r
    
    def article(self, identifier, method='natural_id', start=None, stop=None, precision='year'):
        """
        Returns statistics for a given natural ID.

        Parameters
        ----------
        identifier: str
            Article identifier, typically the article's
            natural ID or its URL.
        
        method: str, default 'natural_id'
            Either `natural_id` or `url`.
        
        start, stop: datetime, default None
            Period boundary for collecting
            statistics. If None, then it will return
            all available statistics for a given
            precision.
        
        precision: str, default 'year'
            Precision of given statistic. Depending
            on how far back the period goes, the Stats API
            may not have data available.

        Returns
        -------
        r: dict
            Dictionary with all statistics avaialble
            for a given content element.
        """
        if method is 'url':
            raise NotImplementedError('Method `url` has not yet been implemented.')
        
        publication_date = self.__publication_date(identifier)
        if (datetime.now() - publication_date).days > self.precision_day_limits[precision]:
            raise ValueError('No data available for the `{}` precision level for article {}'.format(precision, identifier))
        
        date_string = ''
        if start:
            date_string = '{}-'.format(start.strftime(self.__date_format(precision)))
        else:
            if precision == 'month':
                args = { 'days': -30 }
            elif precision == 'year':
                args = { 'days': -365 }
            else:
                args = { precision + 's': -1 }

            start = datetime.now() + timedelta(**args)
            date_string = '{}-'.format(start.strftime(self.__date_format(precision)))
        
        if stop:
            date_string += '{}'.format(stop.strftime(self.__date_format(precision)))
        else:
            stop = datetime.now()
            date_string += '{}'.format(stop.strftime(self.__date_format(precision)))

        identifier_string = 'id.json2?id={}'.format(identifier)

        url = self.url + '/page/all/' + date_string + '/' + identifier_string 

        result = requests.get(url)
        r = result.json()['data']

        for article in r:
            article['date'] = datetime.strptime(article['date'], '%a, %d %b %Y %H:%M:%S %Z')

        return r
