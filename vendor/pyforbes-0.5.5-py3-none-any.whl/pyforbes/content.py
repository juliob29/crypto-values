"""
Class for managing the Forbes content API
methods. This class is designed only to retrieve
content from that API having no write abilities.
"""
import re
import time
import random
import requests

from datetime import datetime
from functools import lru_cache
from pyforbes.utilities import clean_body


class Content:
    """
    Class for interacting with the Forbes Content API.
    """
    def __init__(self):

        self.all_url = 'http://api.forbes.com/forbesapi/content/all.json'
        self.naturalids_url = 'http://api.forbes.com/forbesapi/content/naturalids.json'
        self.uri_url = 'http://statsapi.forbes.com:8080/statsapi/getContent.json'
        self.author_url = 'http://api.forbes.com/forbesapi/content/authorid.json'

    def __parse_brandvoice(self, d):
        """
        Method for detecting if an article is BrandVoice or
        not from a ContentAPI response.

        Returns
        -------
        r: bool
            True if it's a BrandVoice article, False
            if not.
        """
        r = False
        for a in d['authors']:
            try:
                if a['type'] == 'AdVoice':
                    r = True
            except KeyError:
                continue

        return r

    def recent_articles(self, backwards_time=60*60*2, n=10, only_ids=False, **kwargs):
        """
        Used for retrieving articles that were published recently. The recency
        of an article is calculated by how far back to go in time using the 
        `backwards_time` parameter. For instance, if you are insterested in 
        retrieving the recent articles published in the last 2 hours, 
        you would pass 60 * 60 * 2 seconds to that parameter.

        Parameters
        ----------
        backwards_time: int, default `60*60*2`
            Number of seconds to go back in time. The default is
            the equivalent to 2 hours.

        n: int, default 10
            Number of articles to return.
        
        only_ids: bool, default False
            If True, the function returns only a list of
            IDs. This is great for working with the function
            as an iterable.

        kwargs:
            Eventually passed to `self.article_list()`
        
        Returns
        -------
        A list of the most recent articles.

        """
        epoch_time = int(time.time())
        articles = self.article_list(
            start=epoch_time - backwards_time,
            stop=epoch_time,
            n=n,
            epoch=True,
            **kwargs)

        if only_ids:
            articles = [i['naturalId'] for i in  articles]

        return articles

    def article_list(self,
                     start,
                     stop,
                     n=None,
                     epoch=False,
                     fields=[
                         'uri', 'title', 'body', 'naturalId', 'displayChannel',
                         'authors'
                     ]):
        """
        Method for retrieving a list of articles from the
        content API using a specified time period.

        Parameters
        ----------
        start, stop: datetime
            Date and time to be used in query as
            a datetime() object.

        n: int
            Limit the list to contain N articles.

        epoch: bool, default False
            Uses the UNIX Epoch time format to determine
            dates. This is useful for getting recent
            articles (i.e. from that last 30 minutes).

        fields: list, default ['uri', 'title', 'body', 'naturalId', 'displayChannel', 'authors']
            Fields to retrieve from the Content API. The
            fields need to match the available fields in
            the API.

        Returns
        -------
        Dictionary with articles with key properties.

        """
        if len(fields) == 0:
            raise ValueError('No fields to retrieve. Pass fields to the `fields` parameter.')

        #
        #  The property `naturalId` is important for determining
        #  if the resulting object is an article or not. We will
        #  be including it in the requested fields list by
        #  default.
        #
        if 'naturalId' not in fields:
            fields.append('naturalId')

        for d in [start, stop]:
            if not any([isinstance(d, int), isinstance(d, datetime)]):
                raise ValueError('`start` and `stop` must be either datetime or UNIX epoch integers.')

        if not isinstance(start, int):
            start = int(start.strftime('%Y%m%d'))
        if not isinstance(stop, int):
            stop = int(stop.strftime('%Y%m%d'))

        default_filters = '[{visible:true},{type:[%22blog%22,%22blogslide%22,%22slide%22]}]'
        payload = {
            'queryfilters': default_filters,
            'limit': n,
            'fromDate': start,
            'toDate': stop
        }
        if fields:
            payload['retrievedfields'] = ','.join(fields)

        if n is None:
            payload.pop('limit')

        if epoch:
            payload['fromDate'] = payload['fromDate'] * 1000
            payload['toDate'] = payload['toDate'] * 1000
            payload['dateType'] = 'ms'

        payload_string = "&".join("{}={}".format(k, v) for k, v in payload.items())

        r = requests.get(self.all_url, params=payload_string)
        try:
            json_result = r.json()['contentList']
        except KeyError as e:
            raise ValueError('Wrong data input: {}'.format(str(e)))

        #
        #  Cleans all objects that are not articles.
        #  This will excluse the occasional video and
        #  gallery items.
        #
        json_result = [j for j in json_result if 'blogAndPostId' in j.get('naturalId')]

        brand_voices_result = []
        for article in json_result:
            article['brandvoice'] = self.__parse_brandvoice(article)
            brand_voices_result.append(article)

        cleaned_list = []
        for article in brand_voices_result:
            cleaned_list.append({ k:article.get(k) for k in fields })

        brand_voices_result = cleaned_list

        return brand_voices_result

    @lru_cache(maxsize=128)
    def author_list(self):
        """
        Fetches a list of available authors from the Content API.

        Returns
        -------
        list
            List of dictionaries with a list of authors
            alongise their atributes.
        """
        url = 'http://api.forbes.com/forbesapi/author/all.json'
        
        r = requests.get(url).json()['authorList']
        return r
    
    @lru_cache(maxsize=128)
    def author_articles(self, natural_id, n=20):
        """
        Fetches the list of articles published by a given author.
        This method only works with site contributors. It will
        not work with blog authors (e.g. Prod Tech blog).

        Parameters
        ----------
        natural_id: str
            Natural ID of article. 
        
        Returns
        -------
        list
            List of posts made by author ordered by recency.
        """
        url = 'http://192.168.16.24/forbesapi/promote/get.json'
        args = {
            'location': 'contrib-{}'.format(natural_id),
            'all': 'true',
            'type': 'map'
        }
    
        try:
            results = requests.get(url, params=args).json()['promotedContent']
            results = results[list(results.keys())[0]]
        except (KeyError, IndexError):
            raise ValueError('Author {} has no data available.'.format(natural_id))
        
        return results

    @lru_cache(maxsize=128)
    def channels(self, sections=True):
        """
        Fetches a list of available channels at Forbes.com.

        Parameters
        ----------
        sections: bool, default True
            If we should include sections in the output.
            When False, the output includes only the
            number of sections not their nested data.
        
        Returns
        -------
        list
            List with all available channels with 
            their native properties.
        """
        url = 'http://api.forbes.com/forbesapi/channels.json'
        r = requests.get(url)
        
        results = r.json()['channelList']
        if not sections:
            section_counts = []
            for channel in results:
                channel_object = { k:channel[k] for k in channel.keys() }
                if channel_object.get('sections'):
                    channel_object['sections'] = len(channel_object['sections'])
                else:
                    channel_object['sections'] = 0

                section_counts.append(channel_object)

            results = section_counts

        return results

    @lru_cache(maxsize=128)
    def hashtags(self):
        """
        Fecthes a full list of currently available hashtags.

        Returns
        -------
        list
            List of strings with hashtags.
        """
        url = 'http://api.forbes.com/forbesapi/content/hashtag/all.json'
        r = requests.get(url)

        results = r.json()['hashtags']
        return results

    @lru_cache(maxsize=128)
    def articles_by_hashtag(self, hashtag, start=None, limit=10):
        """
        Fetches a list of articles by a hashtag.

        Parameters
        ----------
        hashtag: str
            Hashtag to get articles for.
        
        start: int
            Integer where to start pagination.
        
        limit: int
            Number of articles to retrieve per query.

        Returns
        -------
        list
            List of dictionaries.
        """
        payload = {
            'hashtag': hashtag,
            'start': start if start else 0,
            'limit': limit
        }
        payload_string = "&".join("{}={}".format(k, v) for k, v in payload.items())
        url = 'http://api.forbes.com/forbesapi/contents/hashtag.json'
        r = requests.get(url, params=payload_string)

        results = r.json()['contentList']
        if not results:
            raise ValueError('Hashtag {} does not exist.'.format(hashtag))
        
        return results

    @lru_cache(maxsize=128)
    def article(self, identifier, method='natural_id', clean=True):
        """
        Fetches metadata for a single article based on an
        identifier field.

        Parameters
        ----------
        identifier: str
            Identifier field for fetching an article metadata.
        
        method: str, default 'natural_id'
            Method to use when retrieving article metadata.
            Available methods are: 'natural_id' and 'url'.
        
        clean: bool, default True
            If the body of retrieved article should be stripped
            out of HTML and WordPress markup.
        
        Returns
        -------
        Dictionary with the metadata of an article.
        """
        def __get_article_by_url(url):
            if 'http' not in url:
                raise ValueError("URL used doesn't seem to be right: {}".format(url))

            if 'www' not in url:
                url = url.replace('http://', 'http://www.')
                
            if 'https' in url:
                url = url.replace('https://', 'http://')
            
            if not url.endswith('/'):
                url += '/'

            payload = {'url': url}
            payload_string = "&".join("{}={}".format(k, v) for k, v in payload.items())
            r = requests.get(self.uri_url, params=payload_string)

            return r.json()

        def __get_article_by_natural_id(natural_id):
            
            if 'blogAndPostId' not in natural_id:
                raise ValueError("Natural ID {} doesn't map to an article.".format(natural_id))

            payload = {'naturalids': natural_id}
            payload_string = "&".join("%s=%s" % (k, v) for k, v in payload.items())
            r = requests.get(self.naturalids_url, params=payload_string)

            content_data = r.json()['contents']

            if len(content_data) == 0:
                raise ValueError("Natural ID not found in Content API: {}".format(natural_id))

            return content_data[0]

        methods = {
            'natural_id': __get_article_by_natural_id,
            'url': __get_article_by_url
        }
        result = methods[method](identifier)
        if len(result) == 0:
            raise ValueError(
                'Article with ID {} does not exist.'.format(identifier))

        if clean:
            result['body'] = clean_body(result['body'])

        return result
