"""
Manages the interface with Forbes' Relatedness API.
"""
import requests


class Related:
    """
    Class for interactinv with Forbes' Relatedness API.
    """
    def __init__(self):

        self.related_url = 'http://10.11.13.138:8080/relevance/getRelated?id={}'
        self.combined_url = 'http://10.11.13.138:8080/relevance/combineScores?operation={}&naturalIds={}'

    def article(self, id):
        """
        Fetches a list of related articles for a given 
        article.

        Parameters
        ----------
        ids: str
            Single natural ID of an article.

        Returns
        -------
        Dictionary with list of related articles.
        """
        request_url = self.related_url.format(id)
        r = requests.get(request_url)

        return r.json()['list']

    def combined(self, ids, operation='sum'):
        """
        Fetches the combined list of related articles to 
        a set of input articles. The articles can be
        combined using different techniques.

        Parameters
        ----------
        ids: list
            List of natural IDs for key articles.
        
        operation: str
            Operation to perform on the scores of
            the related articles.

        Returns
        -------
        List of combined related articles.
        """
        if type(ids) is not list:
            raise ValueError('`ids` parameter must be a list.')

        request_url = self.combined_url.format(operation, ','.join(ids))
        r = requests.get(request_url)

        return r.json()['result']
