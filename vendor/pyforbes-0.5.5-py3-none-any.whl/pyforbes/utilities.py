"""
Series of utilities useful across the Forbes
package.
"""
import re

from bs4 import BeautifulSoup
from datetime import datetime, timedelta


def date_range(start, stop):
    """
    Creates a list of dates in ISO format.
    This function is useful for creating iterator
    over dates.

    Parameters
    ----------
    start: str
        Start of period in ISO format.

    stop: str
        Start of period in ISO format.
    
    Returns
    -------
    List of dates as strings in ISO format.
    """
    start = datetime.strptime(start, '%Y-%m-%d')
    stop = datetime.strptime(stop, '%Y-%m-%d')
    days = (stop - start).days
    return [(start + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(0, days + 1)]

def clean_body(b):
    '''
    Cleans body of article using BeautifulSoup and
    other methods. This needs to clean both WordPress
    tags and HTML tags.

    Parameters
    ----------
    b: str
        Body of article to parse.
    
    Returns
    -------
    r: str
        Cleaned text without HTML, WordPress markup, 
        and encoding symbols.
    '''
    text_without_html = ''.join(BeautifulSoup(b, 'html5lib').findAll(text=True))
    text_without_wordpress_markup = re.sub(r'\[[^\]]*?\]', '', text_without_html)
    text_without_notpaginate = text_without_wordpress_markup.replace('donotpaginate', '')
    text_without_space = text_without_notpaginate.replace('\xa0', ' ')

    r = text_without_space
    return r
