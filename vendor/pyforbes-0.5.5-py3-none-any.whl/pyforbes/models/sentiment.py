"""
Interface to the Berti.ai model sentiment.
"""
from pyforbes.models.interface import Models


class Sentiment(Models):
    """
    Interface to the Bertie.ai `model-sentiment`.
    The model is documented in the following page:

        * https://github.forbes.com/pages/DataProducts/bertieai-protocol/#/model_sentiment
    
    `model-sentiment` estimates the sentiment of
    text using a series of pre-trained models.
    """
    def __init__(self):

        self.base_url = 'http://models.dataproducts.team/sentiment'

    def text(self, text, method='naive-bayes'):
        """
        Estimates the sentiment of text using a defined 
        method. Sentiment values range from -1 (negative) 
        to 1 (positive).

        Parameters
        ----------
        text: str
            Text input to use for estimating sentiment.
        
        method: str, default 'naive-bayes'
            Method to use in sentiment estimation process.

        Returns
        -------
        dict
            Dictionary with a sentiment estimate.
        """
        payload = {
            'text': text,
            'method': method
        }

        return self._make_request(endpoint='/analyze', payload=payload)
    
    def article(self, article, method='naive-bayes'):
        """
        Estimates the sentiment a published Forbes.com article
        using a defined method. Sentiment values 
        range from -1 (negative) to 1 (positive).

        Parameters
        ----------
        article: str
            URL or natural ID for a given article.
        
        method: str, default 'naive-bayes'
            Method to use in sentiment estimation process.

        Returns
        -------
        dict
            Dictionary with a sentiment estimate.
        """
        payload = {
            'article': article,
            'method': method
        }

        return self._make_request(endpoint='/analyze', payload=payload)
