"""
Interface for Bertie.ai's model-estimator.
"""
from pyforbes.models.interface import Models


class Estimator(Models):
    """
    Class that provides an interface to Bertie.ai's model-estimator.
    That model estimates how well an article will perform based on
    its innate properties. That is, it estimates an article 
    performance before it has been published.

        * https://github.forbes.com/pages/DataProducts/bertieai-protocol/#/model_estimator

    """
    def __init__(self):
        self.base_url = 'http://models.dataproducts.team/estimator'
    
    def text(self, text):
        """
        Estimates the number of pageviews a piece of
        text will receive.

        Parameters
        ----------
        text: str
            Piece of text to be used to estimate
            complexity.

        Returns
        -------
        dict
            Predicted pageviews that a piece of text
            will receive and a list of sentences with
            the contribution to the predictions.
        """
        payload = {
            'text': text
        }

        return self._make_request(endpoint='/predict', payload=payload)
