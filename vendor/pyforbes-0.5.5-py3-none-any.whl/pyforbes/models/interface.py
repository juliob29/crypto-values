"""
Base class for interfacing with Bertie.ai
models.
"""
import json
import requests


class Models:
    """
    Base class for facilitating the interface
    with Bertie.ai models.

    """
    def status(self):
        """
        Checks the status for a given model.

        Returns
        -------
        dict
            Parsed JSON with the status
            from a given model.
        """
        data = requests.get(self.base_url + '/status')
        return data.json()

    def _make_request(self, endpoint, payload):
        """
        Makes a POST request to a given model.

        Parameters
        ----------
        endpoint: str
            Endpoint to make a request with.
        
        payload: dict
            Payload to be used in request. All payloads
            must be serializable into JSON.
        
        Returns
        -------
        dict
            Results from a given model.
        """
        data = requests.post(self.base_url + endpoint, json=payload)
        
        try:
            result = data.json()
        except json.JSONDecodeError as e:
            raise ValueError('Failed to parse JSON from data: {}'.format(data.text))

        if not result['success']:
            raise ValueError('Error in request: {}'.format(result['message']))

        #
        #  This is a backward compatibility
        #  change for supporting the model-headline-optimizer.
        #
        if not result.get('results'):
            return result

        return result['results']