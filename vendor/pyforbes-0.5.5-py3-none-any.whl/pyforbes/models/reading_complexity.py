"""
Interface for Bertie.ai's model-reading-complexity.
"""
from pyforbes.models.interface import Models


class ReadingComplexity(Models):
    """
    Class that interfaces with Bertie.ai's model-reading-complexity.

    The model estimates how long a piece of text will
    take to read and also categorizes a given piece of text
    using a number of readability models. Detailed
    documentation on how the model works is available here:

        * https://github.forbes.com/pages/DataProducts/bertieai-protocol/#/model_reading_complexity

    """
    def __init__(self):
        self.base_url = 'http://models.dataproducts.team/reading-complexity'
    
    def text(self, text):
        """
        Estimates the complexity of a given piece of text
        using estimated reading time and readability
        models.

        Parameters
        ----------
        text: str
            Piece of text to be used to estimate
            complexity.

        Returns
        -------
        dict
            Dictionary with summary and keywords.
        """
        payload = {
            'text': text
        }

        time_result = self._make_request(endpoint='/time', payload=payload)
        readability_result = self._make_request(endpoint='/readability', payload=payload)

        readability_result['estimate'] = time_result['estimate']

        return readability_result
    
    def article(self, article):
        """
        Estimates the complexity of a published Forbes.com
        article.

        Parameters
        ----------
        article: str
            URL or natural ID for a given article.

        Returns
        -------
        dict
            Dictionary with complexity estimates.
        """
        payload = {
            'article': article
        }

        time_result = self._make_request(endpoint='/time', payload=payload)
        readability_result = self._make_request(endpoint='/readability', payload=payload)

        readability_result['estimate'] = time_result['estimate']

        return readability_result