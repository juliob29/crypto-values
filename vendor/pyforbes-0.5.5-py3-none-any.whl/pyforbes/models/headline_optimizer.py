"""
Interface for Bertie.ai's model-headline-optimizer.
"""
from pyforbes.models.interface import Models


class HeadlineOptimizer(Models):
    """
    Class that provides an interface to Bertie.ai's model-headline-optimizer.
    The model will evaluate how well a headline (i.e. a "title") is performing,
    then it will return a list of suggestion on how to improve it.

        * https://github.forbes.com/pages/DataProducts/bertieai-protocol/#/model_headline_optimizer

    """
    def __init__(self):
        self.base_url = 'http://models.dataproducts.team/headline-optimizer'
    
    def title(self, title):
        """
        Calculates the score of a given headline and 
        issue suggestions on how to improve it.

        Parameters
        ----------
        title: str
            String that represents an article title.

        Returns
        -------
        dict
            Title score and a list of suggestions about
            the title weaknesses and strenghts.
        """
        payload = {
            'title': title
        }

        return self._make_request(endpoint='/api/optimizer/title', payload=payload)
