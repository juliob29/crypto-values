"""
Interface for Bertie.ai's model-entities-recognizer.
"""
from pyforbes.models.interface import Models


class EntitiesRecognizer(Models):
    """
    Class that provides an interface to the `model-entities-recognizer`.
    The model extracts entitites from text, returning a list of ordered
    entities ranked by the most popular in Google Trends (last 30 days.)

        * https://github.forbes.com/pages/DataProducts/bertieai-protocol/#/model_entities_recognizer

    """
    def __init__(self):
        self.base_url = 'http://models.dataproducts.team/entity-recognizer'
    
    def text(self, text):
        """
        Identifies entities in a piece of text and 
        ranks them according to what is trending on 
        Google Search over the last 30 days. This 
        method returns a list of those entities
        ordered by popularity.

        Parameters
        ----------
        text: str
            Piece of text to be used to estimate
            complexity.

        Returns
        -------
        list
            List of ranked entities.
        """
        payload = {
            'text': text
        }

        return self._make_request(endpoint='/entities', payload=payload)
