"""
Interface to the Berti.ai model summarizer.
"""
from pyforbes.models.interface import Models


class Summarizer(Models):
    """
    Interface to the Bertie.ai `model-summarizer`. 
    The model is documented in the following page:

        * https://github.forbes.com/pages/DataProducts/bertieai-protocol/#/model_summarizer
    
    `model-summarizer` summarizes a piece of text
    or a Forbes.com article into N sentences based on 
    C characters.

    Parameters
    ----------
    max_characters: int, default 300
        Number of characters to use as constraint
        in the summarization process.

    """
    def __init__(self, max_characters=300):
        self.max_characters = max_characters

        self.base_url = 'http://models.dataproducts.team/summarizer'

    def text(self, text, method='textrank'):
        """
        Summarizes a piece of text into N number of
        sentences.

        Returns
        -------
        dict
            Dictionary with summary and keywords.
        """
        payload = {
            'text': text,
            'characters': self.max_characters,
            'method': method
        }

        return self._make_request(endpoint='/summarize', payload=payload)
    
    def article(self, article, method='textrank'):
        """
        Summarizes a published Forbes.com article 
        into N number of sentences.

        Parameters
        ----------
        article: str
            URL or natural ID for a given article.
        
        method: str, default 'textrank'
            Method to use in summarization process.

        Returns
        -------
        dict
            Dictionary with summary and keywords.
        """
        payload = {
            'article': article,
            'characters': self.max_characters,
            'method': method
        }

        return self._make_request(endpoint='/summarize', payload=payload)
