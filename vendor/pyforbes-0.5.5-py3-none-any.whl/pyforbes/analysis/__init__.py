"""
Interface for PyForbes Analysis Module
"""

from pyforbes.analysis.pos import Tagger


__all__ = ['Tagger']