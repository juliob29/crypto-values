"""
Part-of-Speech (POS) Tagging Utilities for PyForbes
"""

import re
import spacy


class Tagger:
    """
    A utility class to preprocess text inputs by
    annotating them with their part-of-speech (POS)
    tags. This preprocessing step will enable the
    training of sense2vec models, which relies on
    POS tags in performing word-sense disambiguation.
    
    Parameters
    ----------
    template : str, default `'{}<{}>'`
        The format for the string output. This template
        should take 2 arguments, where the first refers
        to a text and the second refers to its tag. The
        template setting only applies when `display` is
        set to `'both'`. Suggested alternatives include
        `'{}|{}'`.
    
    Methods
    -------
    annotate(doc, display='both')
        Parses an input document to output a list of
        tuples of words and their respective POS tags.
        The `display` argument decides if either of the
        text or tag output (or both) gets printed.
    
    """
    
    def __init__(self, template='{}<{}>'):
        """
        Initialize a language model and a dictionary
        of labels
        """
        self.labels = {
            'ENT': 'ENT',
            'PERSON': 'ENT',
            'NORP': 'ENT',
            'FAC': 'ENT',
            'ORG': 'ENT',
            'GPE': 'ENT',
            'LOC': 'ENT',
            'LAW': 'ENT',
            'PRODUCT': 'ENT',
            'EVENT': 'ENT',
            'WORK_OF_ART': 'ENT',
            'LANGUAGE': 'ENT',
            'DATE': 'DATE',
            'TIME': 'TIME',
            'PERCENT': 'PERCENT',
            'MONEY': 'MONEY',
            'QUANTITY': 'QUANTITY',
            'ORDINAL': 'ORDINAL',
            'CARDINAL': 'CARDINAL'
        }
        self.nlp = spacy.load('en')
        self.template = template
    
    def __tag(self, word):
        """
        Returns the POS tag for a given token
        """
        if word.like_url:
            return '%%URL|X'
        text = re.sub(r'\s', '_', word.text)
        tag = self.labels.get(word.ent_type_, word.pos_)
        if not tag:
            tag = '?'
        return text, tag
    
    def __parse(self, doc, display):
        """
        Computes the POS tags for all component tokens
        of a text document
        """
        for ent in doc.ents:
            ent.merge(tag=ent.root.tag_, lemma=ent.text, ent_type=self.labels[ent.label_])
        output, results = [], []
        for sent in doc.sents:
            if sent.text.strip():
                result = {text: tag for text, tag in [self.__tag(word) for word in sent if not word.is_space]}
                results.extend(result.items())
                if display == 'both':
                    output.append(' '.join([self.template.format(text, tag) for text, tag in result.items()]))
                elif display == 'text':
                    output.append(' '.join(result.keys()))
                elif display == 'tags':
                    output.append(' '.join(result.values()))
        if output:
            print('\n\n'.join(output) + '\n')
        return results
    
    def annotate(self, doc, display='both'):
        """
        Parses an input text document and retrieves the
        POS tag for each component token. The results
        are returned as a list of tuples, where the first
        elements of the tuples are the raw string tokens
        and the second elements are the respective tags.
        
        The method will also print the output based on
        the argument supplied to `display`.
        
        Parameters
        ----------
        doc : str
            The raw string input, which can be an entire
            text document or a short string.
        display : str, default `'both'`
            The options to print the results. This can
            take one of `'both'`, `'text'`, or `'tags'`.
            If `None` or another unspecified string is
            supplied, the method does not print anything.
        
        Returns
        -------
        results : list of tuples
            A list of tuples containing the individual
            tokens and their respective POS tags.
        
        """
        doc = self.nlp(doc)
        display = display.lower() if display else 'None'
        return self.__parse(doc, display)
