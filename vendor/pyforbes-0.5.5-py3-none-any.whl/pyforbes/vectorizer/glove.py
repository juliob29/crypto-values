"""
Utilities for GloVe Word Embeddings
"""
import nltk
import keras
import pickle

import numpy as np


class Embedding:
    """
    A utility class to prepare word embeddings for
    integration into Keras models.
    
    Note:
        This class is currently configured for
        GloVe embeddings only.
    
    Download requisite files here:
        https://nlp.stanford.edu/projects/glove/
    
    Parameters
    ----------
    path : str
        Path to (downloaded) pre-trained GloVe vectors.
    mode : str, default None
        A flag to indicate whether the class is being
        used for training (`train`) or production
        (`None`) purposes. If `mode==None`, the model
        expects `path` to point to a word2idx object
        as a pickle object, i.e. `word2idx.pkl`.

    Attributes
    ----------
    word2idx : dict
        Mapping of words to their vector indices.
    idx2word : dict
        Mapping of vector indices to words.
    word2vec : dict
        Mapping of words to their embedding vectors.
    
    Methods
    -------
    sent2idx(X, word2idx, max_len=30)
        Converts a raw text input to a numpy array of indices.
    custom_embedding(word2vec, word2idx, trainable=False)
        Creates a custom embedding layer for Keras models.
    
    """
    
    def __init__(self, path, mode=None):
        """
        Parse raw GloVe files into dictionaries
        """
        if mode == 'train':
            
            with open(path, 'r') as file:
                words = set()
                word2vec = {}
                for line in file:
                    line = line.strip().split()
                    word = line[0]
                    words.add(word)
                    word2vec[word] = np.array(line[1:], dtype=np.float64)
                word2idx = {}
                idx2word = {}
                for i, word in enumerate(sorted(words), 1):
                    word2idx[word] = i
                    idx2word[i] = word
                
        else:
            
            with open(path, 'rb') as file:
                word2idx = pickle.load(file)
            idx2word = None
            word2vec = None
        
        self.word2idx = word2idx
        self.idx2word = idx2word
        self.word2vec = word2vec
    
    def sent2idx(self, X, word2idx=None, max_len=30):
        """
        Converts an input of raw texts into a list of
        their GloVe vector indices.
        
        Parameters
        ----------
        X : np.ndarray
            A numpy array of raw texts of shape (m,).
        word2idx : dict, optional
            A dictionary mapping of words to their vector
            indices. If not supplied, the model will default
            to `self.word2idx`.
        max_len : int, default 30
            The maximum length of the output vector. Shorter
            sentences will be padded with zeros, while
            longer ones will be truncated.
        
        Returns
        -------
        X_idx : np.ndarray
            A numpy array of word indices of shape (m, max_len).
        
        """
        if word2idx is None:
            word2idx = self.word2idx
        
        m = X.shape[0]
        X_idx = np.zeros((m, max_len))
        for i in range(m):
            words = [word.lower() for word in nltk.word_tokenize(X[i])]
            for j, word in enumerate(words):
                try:
                    X_idx[i, j] = word2idx[word]
                except:
                    try:
                        X_idx[i, j] = word2idx['unk']
                    except IndexError:
                        break
        
        return X_idx
    
    def custom_embedding(self, word2vec=None, word2idx=None, trainable=False):
        """
        Creates a custom embedding layer for
        integration into Keras models.
        
        Warning:
            Can only be used when `mode='train'`
        
        Parameters
        ----------
        word2vec : dict, optional
            A mapping of words to their respective
            embedding vectors. If not supplied, the
            model defaults to `self.word2vec`.
        word2idx : dict, optional
            A mapping of words to their respective
            vector indices. If not supplied, the
            model defaults to `self.word2idx`
        trainable : bool, default False
            A flag to indicate whether or not the custom
            layer should be trained by the Keras model,
            or kept fixed.
        
        Returns
        -------
        custom_layer : keras.layers.embeddings.Embedding
            A custom Keras layer that can be integrated
            into a Keras model.
        
        """
        if word2idx is None:
            word2idx = self.word2idx
        
        vocab_len = len(word2idx) + 1
        
        if word2vec is None:
            word2vec = self.word2vec
        
        embedding_dim = word2vec['a'].shape[0]
        
        embedding_matrix = np.zeros((vocab_len, embedding_dim))
        
        for word, i in word2idx.items():
            embedding_matrix[i, :] = word2vec[word]
        
        custom_layer = keras.layers.Embedding(vocab_len, embedding_dim, trainable=trainable)
        custom_layer.build((None,))
        custom_layer.set_weights([embedding_matrix])
        
        return custom_layer
