"""
doc2vec Utilities for PyForbes
"""

import collections
import gensim
import os
import random
import time

from progressbar import ProgressBar
from smart_open import smart_open


class doc2vec:
    """
    A vectorizer class to preprocess documents and other
    text inputs for integration into sequence models.
    
    This class can be initialized in training and/or
    production modes (not mutually exclusive). For
    training purposes, a text corpus for training (and
    optionally, a test corpus for evaluation) must be
    supplied. For production purposes, a pre-trained
    model must be supplied.
    
    Parameters
    ----------
    corpus : str, default `None`
        Path to a directory containing a training corpus
    model : str, default `None`
        Path to a directory containing a pre-trained model
    
    Methods
    -------
    train(size=300, epochs=100, update=None, **kwargs)
        Trains a doc2vec model based on a training corpus.
        Additional keyword arguments will be passed on to
        gensim.models.Doc2Vec().
    evaluate(corpus=None, i=None)
        Evaluates the current initialized model (for both
        training and production modes) on a test corpus.
    vectorize(text)
        Converts a text input (i.e. an article, document
        or piece of text) into a vector (numpy array). The
        dimension of the output depends on the model supplied.
    
    """
    
    def __init__(self, model=None, corpus=None):
        """
        Initialize a vectorizer in training and/or production
        mode. At least one mode must be specified.
        """
        if corpus is None and model is None:
            raise Exception('One of `corpus` (training mode) or `model` (production mode) must be supplied.')
        else:
            if corpus:
                self.corpus = list(self.__load_corpus(corpus, train=True))
            if model:
                self.model = gensim.models.Doc2Vec.load(model)
                self.model.delete_temporary_training_data()
    
    def __load_corpus(self, path, train=False):
        """
        Parses a text corpus into the appropriate format. For
        training purposes, this will be a TaggedDocument object.
        For testing purposes, this will be a list.
        """
        with smart_open(path) as corpus:
            for i, doc in enumerate(corpus):
                doc = self.__tokenize(doc)
                if train:
                    yield gensim.models.doc2vec.TaggedDocument(doc, [i])
                else:
                    yield doc
    
    def __tokenize(self, text):
        """
        Convert a document into a list of tokens
        """
        return gensim.utils.simple_preprocess(text, deacc=True)
    
    def vectorize(self, text):
        """
        Converts a piece of text input into a vector. The
        dimensions will depend on the doc2vec model supplied.
        
        Parameters
        ----------
        text : str
            A piece of text input, (i.e. an article, document,
            or other piece of text)
        
        Returns
        -------
        np.ndarray
            A vectorized version of the text input as a numpy
            array. The dimensions depend on the model supplied.
        
        """
        tokens = self.__tokenize(text)
        
        return self.model.infer_vector(tokens)
    
    def train(self, size=300, epochs=100, update=None, verbose=False, **kwargs):
        """
        Trains and saves a doc2vec model based on a training
        corpus. Outputs an initial evaluation of the trained model
        based on self-similarity rank.
        
        Parameters
        ----------
        size : int, default 300
            The dimension of the output vector, which will be the
            vectorized representation of the input text
        epochs : int, default 100
            The number of epochs to train the model on the
            training corpus
        update : str, default `None`
            Path to a pre-trained model that will be further
            trained for additional epochs
        verbose : bool, default False
            Whether or not to print an initial evaluation of the
            model based on self-similarity rank
        **kwargs : dict, optional
            A dictionary of additional keyword arguments that
            will be passed on to gensim.models.Doc2Vec()
        
        Returns
        -------
        results : dict
            A dictionary of self-similarity ranks for each
            training sample in the corpus.
        
        """
        train_corpus = list(self.corpus)
        n = len(train_corpus)

        if update is None:
            self.model = gensim.models.Doc2Vec(vector_size=size, **kwargs)
            self.model.build_vocab(train_corpus)
            if not os.path.exists('models'):
                os.mkdir('models')
            path = 'models/{}d.{}.doc2vec'.format(size, int(time.time()))
        else:
            path = update
            self.model = gensim.models.Doc2Vec.load(path)

        bar, rank = ProgressBar(), []
        for _ in bar(range(int(epochs))):
            random.shuffle(train_corpus)
            self.model.train(train_corpus, total_examples=n, epochs=1)
        self.model.save(path)
        self.model.delete_temporary_training_data()

        for i in range(n):
            vector = self.model.infer_vector(self.corpus[i].words)
            sims = self.model.docvecs.most_similar([vector], topn=n)
            rank.append([i for i, sim in sims].index(i))
        
        results = collections.Counter(rank).items()
        
        if verbose:
            _ = 'Self-Similarity Rank'
            print(_ + '\n' + '=' * len(_) + '\n')
            for k, v in results:
                print('{}: {:>{}} {:>8}'.format(k, v, len(str(n)) + 1, '({:.2f}%)'.format(v / n * 100)))
        
        return results
    
    def evaluate(self, corpus=None, i=None, verbose=True):
        """
        Evaluates the underlying model (for both training
        or production mode) on a testing corpus. Prints
        a report containing the most similar, median, and
        least similar article/document for a given training
        input, and their respective similarity scores.
        
        Parameters
        ----------
        corpus : str, default `None`
            Path to a directory containing a testing corpus
        i : int, default `None`
            The index of the training article/document to
            evaluate. If none is provided, an index will be
            randomly chosen.
        verbose : bool, default True
            Whether or not to print the output of the
            evaluation on a given test sample
        
        """
        if corpus:
            test_corpus = list(self.__load_corpus(corpus))
        else:
            test_corpus = self.corpus
        
        if i is None:
            i = random.randint(0, len(test_corpus) - 1)
        
        try:
            tokens = test_corpus[i].words
        except AttributeError:
            tokens = test_corpus[i]
        finally:
            vector = self.model.infer_vector(tokens)
        
        sims = self.model.docvecs.most_similar([vector], topn=len(self.model.docvecs))
        
        if verbose:
            print('TARGET ({}): «{}»\n'.format(i, ' '.join(tokens)))
            print(u'SIMILAR/DISSIMILAR DOCS PER MODEL %s:\n' % self.model)
            for label, index in [('MOST', 0), ('MEDIAN', len(sims)//2), ('LEAST', len(sims) - 1)]:
                print(u'%s %s: «%s»\n' % (label, sims[index], ' '.join(self.corpus[sims[index][0]].words)))
