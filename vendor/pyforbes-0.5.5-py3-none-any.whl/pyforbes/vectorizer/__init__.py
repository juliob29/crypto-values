"""
Interface for PyForbes Vectorizer Module
"""

from pyforbes.vectorizer.doc2vec import doc2vec
from pyforbes.vectorizer.glove import Embedding


__all__ = ['doc2vec', 'Embedding']