"""
Metadata for PyForbes.
"""

__version__ = (0, 5, 5)
__maintainer__ = 'Luis Capelo'
__email__ = 'lcapelo@forbes.com'
__contributors__ = ['lcapelo', 'dkang', 'icarrasco']
