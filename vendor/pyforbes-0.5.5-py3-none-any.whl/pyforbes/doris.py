"""
Logic for handling methods from the StatsAPI.
"""
import requests

from datetime import datetime, timedelta


class Doris:
    """
    Class that representing the interface with 
    Forbes' Doris API.
    """
    def __init__(self):

        self.url = 'http://doris.dataproducts.team'
    
    def graph(self, article, start, stop, precision='hour', sharecode=None, 
              internal=False, search=False):
        """
        Method for getting a complete graph from Doris. That graph 
        can be then analyzed.

        Parameters
        ----------
        article: str
            URL or natural ID of aticle.

        start, stop: datetime
            Datetime object that is eventually parsed into
            the required format by Doris.
        
        precision: str, default 'hour'
            The precision to use when grouping values
            in Doris. 

        sharecode: str, default None
            If included, Doris will return all the trees
            that have started with a particular sharecode.

        internal: bool, default False
            If the resulting graph should include internal traffic.

        search: bool, default False
            If the resulting graph should include search traffic.

        Returns
        -------
        r: dict
            Dictionary of parsed JSON.

        """
        payload = {
            'article': article,
            'start': start.strftime('%Y-%m-%d'),
            'stop': stop.strftime('%Y-%m-%d'),
            'precision': precision
        }

        for name in ['sharecode', 'internal', 'search']:
            payload[name] = eval(name)

        result = requests.post(self.url + '/graph', json=payload)

        r = result.json()
        return r
