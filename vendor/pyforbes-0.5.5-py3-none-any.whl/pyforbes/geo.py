"""
Interface for the Geo filtering API. This
service runs the same Velocity algorithm (i.e. Content().top())
for the pages visited from a certain region, returning
the articles most popular viewed in that region.
"""
import requests

from functools import lru_cache


class Geo:
    """
    Interface for the Geo filtering API. 
    """
    def __init__(self):

        self.url = 'http://statsapi.forbes.com:8080/statsapi/recommend'

    @lru_cache(maxsize=128)
    def articles(self, region, hour, day, n=10, mobile_visits_only=False, referrer=None):
        """
        Fetches articles that are popular in a given 
        geography. The geography uses an ISO 2-letter
        code for a country. If the query is done in the US,
        it can be further specified up to a state. 

        Parameters
        ----------
        region: str
            ISO 2-letter country codes (e.g. US). If querying
            for a US state, one can also specify that state
            such as: USNY
        
        n: int
            Maximum number of articles to return.
        
        hour: int
        
        day: int

        mobile_visits_only: bool, default False

        referrer: str
            To filter for a specific referrer. One can use either
            a fully qualified url or the name of a known referrer.
            The latter can be: 'Google', 'Twitter', and more.
        """
        payload = {
            'mb': 'T' if mobile_visits_only else 'F',
            'region': region,
            'enhance': 1,
            'hour': hour,
            'day': day,
            'n': n,
            'region': region

        }
        if referrer is not None:
            data['referrer'] = referrer

        try:
            results = requests.get(self.url, data=payload).json()['data']
        except KeyError:
            raise ValueError('No data returned.')
        
        return results
    