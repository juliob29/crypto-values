"""
Interface for Forbes.com Search API.
"""
import requests


class Search:
    """
    Class that provides inter
    """
    def __init__(self):

        self.url = 'https://api.forbes.com/forbesapi/search/content.json'
    
    def text(self, text, limit=10, retrieved_fields='uri,title,naturalId,displayChannel,authors'):
        """
        Makes an opinionated search to the Forbes search API.

        Parameters
        ----------
        text: str
            Text string to use. This passes the text string to the
            Forbes Solr enginge, hence using that engine's specification
            for making queries will work here as well.
        
        limit: int, default 10
            Default number of articles to return in output.

        retrieved_fields: str, default 'uri,title,naturalId,displayChannel,authors'
            Fields to retrieve from the document.
        
        Returns
        -------
        A dictionary with the status of the search and retrieved
        fields.
        """
        payload = {
            'limit': str(limit),
            'queryfilters': '[{visible:true},{type:[%22blog%22,%22blogslide%22,%22slide%22]}]',
            'retrievedfields': retrieved_fields,
            'query': text
        }
        payload_string = "&".join("%s=%s" % (k,v) for k,v in payload.items())
        r = requests.get(self.url, params=payload_string)

        if r.ok:
            try:
                results = {
                    'success': True,
                    'results': r.json()['contentList']
                }
            except KeyError:
                results = {
                    'success': False,
                    'message': 'No articles found.',
                    'results': []
                }

        else:
            results = {
                'success': False,
                'message': 'No articles found.',
                'results': []
            }
        
        return results
